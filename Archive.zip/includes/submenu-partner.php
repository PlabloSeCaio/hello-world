<div class="submenu">
	<div class="interior">
		<ul class="submenu_ul">
			<li class="submenu_li current-item"><a href="testimonials.html">Why Partner with us?</a></li> | 
			<li class="submenu_li"><a href="our-partners.html">Our Partners</a></li> | 
			<li class="submenu_li"><a href="register-org.html">Register Your Organisation</a></li> | 
			<li class="submenu_li"><a href="submit-project.html">Submit a Project</a></li>
		</ul>
	</div>
</div>