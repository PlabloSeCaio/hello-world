<div class="submenu">
	<div class="interior">
		<ul class="submenu_ul">
			<li class="submenu_li current-item"><a href="become-volunteer.html">Become a Volunteer</a></li> | 
			<li class="submenu_li"><a href="volunteer-opportunities.html">Search Volunteer Projects</a></li> | 
			<li class="submenu_li"><a href="vchallenge.html">V Challenge</a></li> | 
			<li class="submenu_li"><a href="http://www.cvx.vctt.org/" target="_blank">Caribbean Volunteer eXchange</a></li>
		</ul>
	</div>
</div>