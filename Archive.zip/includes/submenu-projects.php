<div class="submenu">
	<div class="interior">
		<ul class="submenu_ul">
			<li class="submenu_li current-item"><a href="volunteer-opportunities.html">Recent Projects</a></li> | 
			<li class="submenu_li"><a href="vctt-programs.html">VCTT Programs</a></li> | 
			<li class="submenu_li"><a href="feat-project.html">Featured Project</a></li> | 
			<li class="submenu_li"><a href="our-impact.html">Our Impact</a></li>
		</ul>
	</div>
</div>