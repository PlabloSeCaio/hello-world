<div class="submenu">
	<div class="interior">
		<ul class="submenu_ul">
			<li class="submenu_li current-item"><a href="signed-in.html">My Projects</a></li> | 
			<li class="submenu_li"><a href="volunteer-opportunities.html">Search for projects</a></li> | 
			<li class="submenu_li"><a href="services.html">Sustainable Development Goals</a></li> | 
			<li class="submenu_li"><a href="contact-vctt.html">Contact us</a></li>
		</ul>
	</div>
</div>