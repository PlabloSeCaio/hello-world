<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta name="description" content=""/>
	<meta name="keywords" content=""/>
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<title>VCTT - A volunteer in every home</title>
	<link rel="icon" type="image/ico" href="images/favicon.ico">

	<link href="https://fonts.googleapis.com/css?family=Nunito:400,600,800|Raleway:300,400" rel="stylesheet">

	<link rel="stylesheet" href="style.css">



	<!-- Magnific Popup core CSS file -->
	<link rel="stylesheet" href="includes/Magnific-Popup-master/dist/magnific-popup.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- Magnific Popup core JS file -->
	<script src="includes/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>


</head>
<body id="body_bg">
<div class='web_container'>
<header class="page-header">
	<div class="signin__bar">
		<div class="interior">
			<div class="welcome_message">
				Hello <a title="Profile" href="signed-in.html">Giselle</a>
			</div>
			<div class="signin_links">
				<a title="My Profile" href="signed-in.html" class="singIn"><span class="text">My Profile</span></a>
				<a title="Log Out" href="index.html" class="log_out"><span class="text">Log Out</span></a>
				<a title="Support our cause" href="support.html" class="donate"><span class="text">Support</span></a>
			</div>
		</div>
	</div>
	<nav class="masthead__nav">
		<div class="interior">
			<div class="masthead__logo">
				<a class="logo" href="index.html"><h1>Welcome to Vctt.org - A volunteer in every home</h1></a>
			</div>
			<ul class="masthead__ul">
				<li class="menu-item feature">
					<a class="menu-item-link" href="volunteer-opportunities.html"><span class="menu-item-title dropdown">Volunteer</span></a>
					<div class="flyout_menu">
						<article class="col_margin_right col1">
							<div class="feat_box flyout_feat_art_img">
								<div class="img_gradient"></div>
								<h3 class="flyout_article_title">National Survey on Volunteerism</h3>
							</div>
							<p class="feat_art_desc">The Volunteer Center of Trinidad and Tobago (VCTT) challenges the average Trinidad and Tobago citizen to and in touching lives and shifting minds. It acknowledges that people themselves are the most important asset for their own progress, which can only be sustained through their own leadership and ownership of the process.</p>
							<a href="volunteerism-survey.html" class="btn btn-primary see_opportuniy">Read More</a>
						</article>
						<div class="col2 vertical_cols">
							<h2 class="flyout_slogan">A Volunteer in Every Home</h2>
							<div class="flyout_list_articles horizontal_cols">
								<ul class="flyout_list col_50per col_margin_right ">
									<li class="flyout_li view_opp"><a href="volunteer-opportunities.html">Volunteer Now</a></li>
									<li class="flyout_li vchallenge"><a href="vchallenge.html">V Challenge</a></li>
									<li class="flyout_li become_vol"><a href="become-volunteer.html">Become a Volunteer</a></li>
									<!-- <li class="flyout_li levels"><a href="membership-levels.html">Membership Levels</a></li> -->
									<li class="flyout_li why_vol"><a href="why-volunteer.html">Why Volunteer</a></li>
									<li class="flyout_li cvx"><a href="http://www.cvx.vctt.org/" target="_blank">Caribbean Volunteer eXchange</a></li>
									<li class="flyout_li survey"><a href="volunteerism-survey.html">National Survey on Volunteerism</a></li>
								</ul>
							
								<div class="flyout_articles col_50per">
									<a class="feat_box flyout_vchallenge_box vchallenge_img" href="vchallenge.html"><article>
										<div class="img_gradient"></div>
										<h3 class="flyout_article_title">V Challenge</h3>
									</article></a>
									<a class="feat_box flyout_exchange_box" href="http://www.cvx.vctt.org/" target="_blank"><article>
										<div class="img_gradient"></div>
										<h3 class="flyout_article_title">Caribbean Volunteer eXchange</h3>
									</article></a>
								</div>
							</div>
						</div>
					</div>
				</li>
				<li class="menu-item feature">
					<a class="menu-item-link" href="our-partners.html"><span class="menu-item-title dropdown">Partner</span></a>
					<div class="flyout_menu">
						<article class="col_margin_right col1">
							<h3 class="col_h3">Partner with us:</h3>
							<div class="feat_box">
								<img class="feat_partner_img" src="images/partner-with-us.jpg" alt="partner with vctt">
							</div>
							<p class="feat_art_desc">The Volunteer Center of Trinidad & Tobago (VCTT) collaborates with NGOs and CBOs whose projects align with the Sustainable Development Goals on a full spectrum volunteer matching system.</p>

							<p class="feat_art_desc">To qualify for our services organisations must be legally registered with a proven record of community engagement and impact.</p>
							<a href="testimonials.html" class="btn partner_btn btn-primary partner_btn_uno">Why partner with us?</a>
							<a href="our-partners.html" class="btn partner_btn partner_btn_dos">Our Partners</a>
						</article>
						<div class="partner_link_boxes">
								<a href="submit-project.html" class="partner_link_box feat_box submitPro_box">
									<article>
										<div class="img_gradient"></div>
										<h3 class="flyout_article_title">Submit a Project</h3>
									</article>
								</a>
								<a href="register-org.html" class="partner_link_box feat_box register_box">
									<article>
										<div class="img_gradient"></div>
										<h3 class="flyout_article_title">Register Organization</h3>
									</article>
								</a>
						</div>
						
					</div>
				</li>
				<li class="menu-item"><a class="menu-item-link" href="volunteer-opportunities.html" title="Projects"><span class="menu-item-title projects_menu_icon"></span></a>
					<div class="flyout_menu">
						<div class="col2 col_margin_right">
							<h3 class="col_h3">Find Projects by Sustainable Development Goals</h3>
							<div class="sdg_lists">
								<ul class="sdg_ul ul_uno">
									<li class="sdg_li one"><a href="volunteer-opportunities.html?sdg=one">No Poverty</a></li>
									<li class="sdg_li two"><a href="volunteer-opportunities.html?sdg=two">Zero Hunger</a></li>
									<li class="sdg_li three"><a href="volunteer-opportunities.html?sdg=three">Good Health</a></li>
									<li class="sdg_li four"><a href="volunteer-opportunities.html?sdg=four">Quality Education</a></li>
									<li class="sdg_li five"><a href="volunteer-opportunities.html?sdg=five">Gender Equality</a></li>
									<li class="sdg_li six"><a href="volunteer-opportunities.html?sdg=six">Clean Water</a></li>
									<li class="sdg_li seven"><a href="volunteer-opportunities.html?sdg=seven">Clean Energy</a></li>
									<li class="sdg_li eight"><a href="volunteer-opportunities.html?sdg=eight">Decent Work/ Econ. Growth</a></li>
									<li class="sdg_li nine"><a href="volunteer-opportunities.html?sdg=nine">industry & infrastrycture</a></li>
								</ul>
								<ul class="sdg_ul">
									<li class="sdg_li ten"><a href="volunteer-opportunities.html?sdg=ten">Reduce Inequalities</a></li>
									<li class="sdg_li eleven"><a href="volunteer-opportunities.html?sdg=eleven">Sustainable communities</a></li>
									<li class="sdg_li twelve"><a href="volunteer-opportunities.html?sdg=twelve">Responsible consumption</a></li>
									<li class="sdg_li thirteen"><a href="volunteer-opportunities.html?sdg=thirteen">Climate action</a></li>
									<li class="sdg_li fourteen"><a href="volunteer-opportunities.html?sdg=fourteen">Life below water</a></li>
									<li class="sdg_li fifteen"><a href="volunteer-opportunities.html?sdg=fifteen">Life On Land</a></li>
									<li class="sdg_li sixteen"><a href="volunteer-opportunities.html?sdg=sixteen">Peace & Justice</a></li>
									<li class="sdg_li seventeen"><a href="volunteer-opportunities.html?sdg=seventeen">Partnerships for the Goals</a></li>
									<li class="sdg_li all"><a href="volunteer-opportunities.html">See All</a></li>
								</ul>
							</div>

						</div>
						<div class="col1 projects_link_boxes">
							<a href="feat-projects.html" class="projects_link_box feat_box feat_bg">
								<article>
									<div class="img_gradient"></div>
									<h3 class="flyout_article_title">Featured Projects</h3>
								</article>
							</a>
							<a href="vctt-programs.html" class="projects_link_box feat_box vctt_bg">
								<article>
									<div class="img_gradient"></div>
									<h3 class="flyout_article_title">VCTT Programs</h3>
								</article>
							</a>
							<a href="index.html#our-impact" class="projects_link_box feat_box impact_bg">
								<article>
									<div class="img_gradient"></div>
									<h3 class="flyout_article_title">Our Impact</h3>
								</article>
							</a>
						</div>
					</div>
				</li>
				<li class="menu-item">
					<a class="menu-item-link" href="why-are-we-here.html" title="Our Community"><span class="menu-item-title our_community_menu_icon"></span></a>
					<div class="flyout_menu">
						<div class="col2 col_margin_right stats_and_lists">	
							<h3 class="col_h3">Our Community</h3>
							<div class="boxes_below_stats">
								<ul class="col_50per flyout_community_list left_column">
									<li class="flyout_community_list_item why_are_we_here"><a class="menu_icon_li" href="why-are-we-here.html">Why are we here</a></li>
									<li class="flyout_community_list_item our_community"><a class="menu_icon_li" href="community.html">Our Community</a></li>
									<li class="flyout_community_list_item who_we_serve"><a class="menu_icon_li" href="who-we-serve.html">Who we Serve</a></li>
									<li class="flyout_community_list_item our_resources"><a class="menu_icon_li" href="our-resources.html">The V Library</a></li>
									<li class="flyout_community_list_item our_services"><a class="menu_icon_li" href="services.html">Our services to you</a></li>
								</ul>
								<ul class="col_50per flyout_community_list">
									<li class="flyout_community_list_item testimonials"><a class="menu_icon_li" href="testimonials.html">Testimonials</a></li>
									<li class="flyout_community_list_item media"><a class="menu_icon_li" href="https://www.facebook.com/pg/vctt.org/photos/?ref=page_internal" target="_blank">Media</a></li>
									<li class="flyout_community_list_item donate"><a class="menu_icon_li" href="support.html">Support our cause</a></li>
									<li class="flyout_community_list_item contact"><a class="menu_icon_li" href="contact-vctt.html">Contact Us</a></li>
								</ul>
							</div>
						</div>
						<div class="vol_calltoaction">
							<div class="cta_all_content">
								<div class="img_gradient"></div>
								<div class="cta_content">
									<h2 class="vol_title">Volunteer</h2>
									<a href="become-volunteer.html" class="btn partner_btn btn-primary partner_btn_uno">Become a Volunteer</a>
									<a href="support.html" class="btn partner_btn partner_btn_dos">Donate</a>
								</div>
								
							</div>
						</div>
					</div>
				</li>
			</ul>
			<a href="#" id="mobile-menu" class="burger_menu"></a>
		</div>
		<div class="mobile_menu">
			<div class="interior_dos">
				<div class="column col_one">
					<h3 class="mob_menu_title">Volunteer</h3>
					<ul class="flyout_list">
						<li class="flyout_li"><a href="volunteer-opportunities.html">View Opportunities</a></li>
						<li class="flyout_li"><a href="become-volunteer.html">Become a Volunteer</a></li>
						<li class="flyout_li"><a href="why-volunteer.html">Why Volunteer</a></li>
						<li class="flyout_li"><a href="vchallenge.html">V Challenge</a></li>
						<li class="flyout_li"><a href="http://www.cvx.vctt.org/" target="_blank">Caribbean Volunteer eXchange</a></li>
						<li class="flyout_li"><a href="volunteerism-survey.html">National Survey on Volunteerism</a></li>
					</ul>
				</div>
				<div class="column col_two">
					<h3 class="mob_menu_title">Partner</h3>
					<ul class="flyout_list">
						<li class="flyout_li"><a href="our-partners.html">Our Partners</a></li>
						<li class="flyout_li"><a href="testimonials.html">Why Partner with us</a></li>
						<li class="flyout_li"><a href="submit-project.html">Submit a Project</a></li>
						<li class="flyout_li"><a href="register-org.html">Register Organisation</a></li>
					</ul>
				</div>
				<div class="column col_three">
					<h3 class="mob_menu_title">Projects</h3>
					<ul class="flyout_list">
						<li class="flyout_li"><a href="feat-projects.html">Featured Projects</a></li>
						<li class="flyout_li"><a href="vctt-programs.html">VCTT Programs</a></li>
						<li class="flyout_li"><a href="index.html#our-impact">Our Impact</a></li>

					</ul>
				</div>
				<div class="column col_four">
					<h3 class="mob_menu_title">Our Community</h3>
					<ul class="flyout_list">
						<li class="flyout_li"><a href="why-are-we-here.html">Why are we here</a></li>
						<li class="flyout_li"><a href="community.html">Our Community</a></li>
						<li class="flyout_li"><a href="who-we-serve.html">Who we Serve</a></li>
						<li class="flyout_li"><a href="our-resources.html">The V library</a></li>
						<li class="flyout_li"><a href="services.html">Our services to you</a></li>
						<li class="flyout_li"><a href="testimonials.html">Testimonials</a></li>
						<li class="flyout_li"><a href="https://www.facebook.com/pg/vctt.org/photos/?ref=page_internal" target="_blank">Media</a></li>
						<li class="flyout_li"><a href="support.html">Donate</a></li>
						<li class="flyout_li"><a href="contact-vctt.html">Contact Us</a></li>
					</ul>
				</div>
			</div>
		</div>
	</nav>

</header>