<footer class="site_footer">
	<div class="interior">
		<div class="footer_colunms">
			<ul class="footer_col footer_col_ul">VCTT
				<li class="footer_lis"><a href="why-are-we-here.html">About Us</a></li>
				<li class="footer_lis"><a href="services.html">Services</a></li>
				<li class="footer_lis"><a href="feat-projects.html">Featured Projects</a></li>
				<li class="footer_lis"><a href="code-of-conduct.html">Code of Conduct</a></li>
			</ul>
			<ul class="footer_col footer_col_ul">Need Help?
				<li class="footer_lis"><a href="contact-vctt.html">Contact Us</a></li>
				<li class="footer_lis"><a href="why-volunteer.html">Why Volunteer</a></li>
				<li class="footer_lis"><a href="register.html">Register</a></li>
				<li class="footer_lis"><a href="submit-project.html">Find Volunteers</a></li>
			</ul>
			<ul class="footer_col footer_col_ul">My Links
				<li class="footer_lis"><a href="volunteer-opportunities.html">New Projects</a></li>
				<li class="footer_lis"><a href="signed-in.html">My Projects</a></li>
				<li class="footer_lis"><a href="my-volunteers.html">My Volunteers</a></li>

			</ul>
			<div class="footer_col footer_col_banner">
				<div class="fourth_col">
					<img src="images/VCTT-logo-white.png" alt="The Volunteer Center of Trinidad & Tobago">
					<p>We are looking to connect People, Fuel Hope & Collaborate for Change.</p>
					<p>We Want A Volunteer In Every Home.</p>
					<div class="social_icons">
						<a href="https://www.facebook.com/vctt.org/" target="_blank" class="social_icon facebook"></a>
						<a href="https://www.instagram.com/thevolunteercenterof_tnt/" target="_blank" class="social_icon instagram"></a>
						<a href="https://twitter.com/OfficialVCTT" target="_blank" class="social_icon twitter"></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="footer_bottom">
		<div class="interior">
			<p class="footer__text">&copy; 2017 Volunteer Center of Trinidad & Tobago  |  All Rights Reserved. <a href="privacy-policy.html"> Privacy Policy</a>  |  <a href="credits.html"> Credits</a></p>
		</div>
	</div>
</footer>
</div><!-- ENDS web_container -->
<div class="fixed_social_icons">
	<ul class="social_icons_boxes">
		<li class="social_icon_li">
			<a title="Facebook" href="https://www.facebook.com/vctt.org/" target="_blank"  class="social_icon_a facebook"><i class="icon facebook"></i>Facebook</a>
		</li>
		<li class="social_icon_li">
			<a title="Instagram" href="https://www.instagram.com/thevolunteercenterof_tnt/" target="_blank" class="social_icon_a instagram"><i class="icon instagram"></i>Instagram</a>
		</li>
		<li class="social_icon_li">
			<a title="Twitter" href="https://twitter.com/OfficialVCTT" target="_blank" class="social_icon_a twitter"><i class="icon twitter"></i>Twitter</a>
		</li>
		<li class="social_icon_li">
			<a title="Get in Touch" href="contact-vctt.html" class="social_icon_a contact"><i class="icon contact"></i>Contact Vctt</a>
		</li>
	</ul>
</div>

<div title="Go Up" class="back_to_top"></div>

	<script src="app.js"></script>
</body>
</html>