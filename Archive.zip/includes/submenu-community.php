<div class="submenu">
	<div class="interior">
		<ul class="submenu_ul">
			<li class="submenu_li current-item"><a href="why-are-we-here.html">Why are we here</a></li> | 
			<li class="submenu_li"><a href="community.html">Our Community</a></li> | 
			<li class="submenu_li"><a href="services.html">Services</a></li> | 
			<li class="submenu_li"><a href="support.html">Support</a></li> | 
			<li class="submenu_li"><a href="contact-vctt.html">Contact us</a></li>
		</ul>
	</div>
</div>